# كاش مصر | Egypt Wallets Assistant 📱🇪🇬

[![Build Android APK](https://github.com/username/egypt-wallets-app/actions/workflows/build-apk.yml/badge.svg)](https://github.com)
[![Platform](https://img.shields.io/badge/Platform-Android%20%7C%20Web%20PWA-green.svg)](https://github.com)
[![Language](https://img.shields.io/badge/Language-Kotlin%20%7C%20HTML5-blue.svg)](https://kotlinlang.org)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

تطبيق متكامل لتسهيل إرسال، استقبال، وإدارة محافظ الكاش الإلكترونية لجميع شبكات الاتصالات في جمهورية مصر العربية:
**فودافون كاش (Vodafone Cash) • أورنج كاش (Orange Cash) • إي آند كاش (e& Cash) • وي باي (WE Pay) • إنستاباي (InstaPay)**.

---

## 🚀 المميزات الرئيسية (Key Features)

1. **التعرف التلقائي على الشبكة (Smart Network Detection):**
   * بمجرد إدخال الرقم يتعرف التطبيق فوراً على الشبكة:
     * `010` -> فودافون كاش
     * `011` -> إي آند كاش
     * `012` -> أورنج كاش
     * `015` -> وي باي
2. **أتمتة أكواد الاتصال السريع (1-Click USSD Dialer):**
   * توليد كود التحويل المباشر مع المبلغ تلقائياً وإجراء الاتصال دون الحاجة لحفظ وكتابة الأكواد:
     * فودافون: `*9*7*الرقم*المبلغ#`
     * أورنج: `*115*1*الرقم*المبلغ#`
     * إي آند: `*777*1*الرقم*المبلغ#`
     * وي: `*322*1*الرقم*المبلغ#`
3. **استقبال الأموال وتوليد رمز Meeza QR:**
   * توليد كود QR فوري برقم محفظتك والمبلغ.
   * زر بنقرة واحدة لمشاركة رسالة طلب تحويل منسقة للعميل عبر WhatsApp.
4. **حاسبة الرسوم وصافي المبالغ (Reverse Calculator):**
   * حساب رسوم السحب من ماكينات ATM ومنافذ التجار (1%).
   * حاسبة العكس: لمعرفة كم يجب أن يرسل لك العميل بالضبط ليصلك المبلغ المطلوب صافياً بعد خصم عمولة السحب.
5. **سجل المعاملات اليومي وإيصالات الدفع:**
   * حفظ كل التحويلات في دفتر يومية محلي.
   * توليد إيصال رقمي لكل عملية مع إمكانية مشاركته فوراً كإثبات تحويل.
6. **بناء تلقائي للـ APK عبر GitHub Actions (Cloud CI):**
   * عند رفع المشروع على GitHub، تقوم سير العمل (GitHub Actions) ببناء وتجميع ملف الـ `APK` الجاهز للتثبيت تلقائياً وتوفيره للتنزيل المباشر.

---

## 📂 بنية المستودع (Repository Structure)

```text
├── .github/
│   └── workflows/
│       ├── build-apk.yml     # لبناء ملف APK تلقائياً على خوادم GitHub
│       └── pages.yml         # لنشر نسخة الويب أونلاين على GitHub Pages
├── app/                      # كود تطبيق الأندرويد الأصلي (Android Kotlin)
│   ├── src/main/java/com/egyptwallets/cashapp/
│   │   ├── MainActivity.kt           # الواجهة الرئيسية ومعالجة الأوامر
│   │   ├── NetworkDetector.kt        # كاشف الشبكات الذكي
│   │   ├── UssdHelper.kt             # معالج أكواد USSD والاتصال الهاتفي
│   │   ├── FeeCalculator.kt          # حاسبة العمولات والمبالغ الصافية
│   │   └── SmsTransactionReceiver.kt # قارئ إشعارات ورسائل التأكيد SMS
│   └── src/main/res/layout/          # تصميم الواجهات الرسومية
├── docs/
│   └── index.html            # تطبيق الويب التفاعلي PWA (مستضاف مجاناً عبر Pages)
├── build.gradle              # ملفات إعداد Gradle للمشروع
├── settings.gradle
├── .gitignore
├── LICENSE                   # رخصة MIT مفتوحة المصدر
└── README.md
```

---

## 🛠️ خطوات رفع المشروع على حسابك في GitHub (How to Push to GitHub)

### الخطوة 1: إنشاء مستودع جديد على GitHub
1. ادخل على حسابك في [GitHub New Repository](https://github.com/new).
2. اختر اسماً للمستودع (مثال: `egypt-wallets-app`).
3. اختر المستودع **Public** أو **Private**.
4. **لا تضع علامة** على Add README (لأنه مجهز بالفعل).
5. اضغط **Create repository**.

### الخطوة 2: تشغيل أوامر الرفع من جهازك (Terminal)
فك الضغط عن حزمة المشروع المرفقة `EgyptWallets-GitHub-Repo.zip`، ثم افتح موجه الأوامر (Terminal / Git Bash) داخل المجلد واكتب:

```bash
# 1. تهيئة مستودع Git محلي
git init

# 2. إضافة كافة الملفات
git add .

# 3. حفظ أول Commit
git commit -m "Initial commit: Egypt E-Wallets Android App & Web Assistant"

# 4. تعيين الفرع الرئيسي
git branch -M main

# 5. ربط المستودع بحسابك (استبدل YOUR_USERNAME برابط مستودعك)
git remote add origin https://github.com/YOUR_USERNAME/egypt-wallets-app.git

# 6. رفع الملفات إلى GitHub
git push -u origin main
```

---

## 📦 الحصول على ملف الـ APK تلقائياً من GitHub (Automated CI APK Build)
بمجرد عمل `git push`:
1. ادخل على تبويب **Actions** في صفحة مستودعك على GitHub.
2. ستجد وظيفة **Build Android APK** تعمل تلقائياً على خوادم GitHub السحابية.
3. بعد اكتمال البناء (علامة صح خضراء)، اضغط على الـ Run وستجد ملف **EgyptWallets-Debug-APK** متاحاً للتحميل المباشر وتثبيته على هاتفك فوراً دون الحاجة لـ Android Studio!

## 🌐 تشغيل نسخة الويب مجاناً عبر GitHub Pages
لتشغيل واجهة الويب على متصفح هاتفك مباشرة برابط دائم:
1. اذهب إلى **Settings** في مستودعك على GitHub.
2. اختر **Pages** من القائمة الجانبية.
3. في قسم **Build and deployment**، اختر المصدر `Deploy from a branch` والمجلد `/docs`.
4. اضغط **Save** وسيكون موقعك متاحاً على رابط مثل:
   `https://YOUR_USERNAME.github.io/egypt-wallets-app/`
