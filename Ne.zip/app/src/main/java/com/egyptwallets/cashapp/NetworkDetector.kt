package com.egyptwallets.cashapp

enum class WalletNetwork(val titleAr: String, val ussdPrefix: String, val hotline: String) {
    VODAFONE("فودافون كاش", "*9*7*", "7001"),
    ORANGE("أورنج كاش", "*115*1*", "115"),
    ETISALAT("إي آند كاش", "*777*1*", "778"),
    WE("وي باي", "*322*1*", "565"),
    UNKNOWN("غير محدد", "*9*7*", "15997")
}

object NetworkDetector {
    fun detect(phone: String): WalletNetwork {
        val clean = phone.filter { it.isDigit() }
        return when {
            clean.startsWith("010") -> WalletNetwork.VODAFONE
            clean.startsWith("011") -> WalletNetwork.ETISALAT
            clean.startsWith("012") -> WalletNetwork.ORANGE
            clean.startsWith("015") -> WalletNetwork.WE
            else -> WalletNetwork.UNKNOWN
        }
    }
}
